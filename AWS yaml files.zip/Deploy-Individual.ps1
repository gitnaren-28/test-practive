<#
.SYNOPSIS
    Deploy any individual AWS CloudFormation service template
    One script — deploys a single service at a time

.DESCRIPTION
    Each service has its own isolated CloudFormation template.
    Run this script once per service. All parameters are fully
    documented with defaults so you only supply what you need.

.PARAMETER Service
    Name of the service template to deploy (without .yaml).
    Run with -ListServices to see all available options.

.EXAMPLE
    # List all available service templates
    .\Deploy-Individual.ps1 -ListServices

.EXAMPLE
    # Deploy DynamoDB
    .\Deploy-Individual.ps1 -Service dynamodb -ProjectName myapp -EnvironmentName dev -Region ap-south-1

.EXAMPLE
    # Deploy VPC (required first for most other services)
    .\Deploy-Individual.ps1 -Service vpc -ProjectName myapp -EnvironmentName dev -Region ap-south-1

.EXAMPLE
    # Deploy S3 with custom bucket name
    .\Deploy-Individual.ps1 -Service s3 -ProjectName myapp -EnvironmentName dev -S3BucketName my-custom-bucket

.EXAMPLE
    # Deploy Lambda
    .\Deploy-Individual.ps1 -Service lambda -ProjectName myapp -EnvironmentName dev -LambdaRuntime python3.12

.EXAMPLE
    # Deploy RDS PostgreSQL
    .\Deploy-Individual.ps1 -Service rds -ProjectName myapp -EnvironmentName dev `
        -VpcId vpc-0abc1234 -SubnetIds "subnet-aaa,subnet-bbb" `
        -RDSEngine postgres -RDSMasterPassword "MySecure@Pass123"

.NOTES
    Prerequisites: AWS CLI v2 + aws configure
    Deploy ORDER matters for services that need VPC:
        1. vpc  →  2. networking dependencies  →  3. everything else
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    # ── Core ─────────────────────────────────────────────────
    [string]$Service          = "",
    [switch]$ListServices,
    [string]$ProjectName      = "myproject",
    [string]$EnvironmentName  = "dev",
    [string]$Region           = "ap-south-1",
    [string]$TemplateDir      = $PSScriptRoot,

    # ── Shared networking ────────────────────────────────────
    [string]$VpcId            = "",
    [string]$SubnetId         = "",
    [string]$SubnetIds        = "",    # comma-separated for multi-AZ

    # ── VPC ──────────────────────────────────────────────────
    [string]$VpcCIDR               = "10.0.0.0/16",
    [string]$PublicSubnet1CIDR     = "10.0.1.0/24",
    [string]$PublicSubnet2CIDR     = "10.0.2.0/24",
    [string]$PrivateSubnet1CIDR    = "10.0.11.0/24",
    [string]$PrivateSubnet2CIDR    = "10.0.12.0/24",

    # ── EC2 ──────────────────────────────────────────────────
    [string]$EC2InstanceType  = "t3.micro",
    [string]$EC2KeyPairName   = "",
    [int]$EC2VolumeSize       = 20,

    # ── Lambda ───────────────────────────────────────────────
    [string]$LambdaRuntime    = "python3.12",
    [int]$LambdaMemorySize    = 256,
    [int]$LambdaTimeout       = 30,
    [int]$LambdaReservedConcurrency = 10,

    # ── ECS Fargate ───────────────────────────────────────────
    [string]$ECSContainerImage = "nginx:latest",
    [int]$ECSContainerPort     = 80,
    [string]$ECSTaskCPU        = "256",
    [string]$ECSTaskMemory     = "512",
    [int]$ECSDesiredCount      = 1,

    # ── Auto Scaling ─────────────────────────────────────────
    [int]$ASGMinSize           = 1,
    [int]$ASGMaxSize           = 4,
    [int]$ASGDesiredCapacity   = 1,
    [int]$ASGCPUTarget         = 60,

    # ── Elastic Beanstalk ─────────────────────────────────────
    [string]$BeanstalkPlatform = "64bit Amazon Linux 2023 v4.0.1 running Python 3.11",
    [string]$BeanstalkInstanceType = "t3.micro",

    # ── S3 ───────────────────────────────────────────────────
    [string]$S3BucketName      = "",
    [int]$S3GlacierDays        = 90,
    [int]$S3ExpirationDays     = 365,

    # ── EFS ──────────────────────────────────────────────────
    [string]$EFSPerformanceMode = "generalPurpose",
    [string]$EFSThroughputMode  = "bursting",

    # ── RDS ──────────────────────────────────────────────────
    [string]$RDSEngine         = "mysql",
    [string]$RDSEngineVersion  = "8.0",
    [string]$RDSInstanceClass  = "db.t3.micro",
    [string]$RDSDBName         = "appdb",
    [string]$RDSMasterUsername = "dbadmin",
    [string]$RDSMasterPassword = "",

    # ── DynamoDB ─────────────────────────────────────────────
    [string]$DynamoTableName   = "app-table",
    [string]$DynamoHashKey     = "PK",
    [string]$DynamoRangeKey    = "SK",
    [string]$DynamoBillingMode = "PAY_PER_REQUEST",

    # ── ElastiCache Redis ─────────────────────────────────────
    [string]$RedisNodeType     = "cache.t3.micro",
    [int]$RedisNumReplicas     = 1,

    # ── Redshift ─────────────────────────────────────────────
    [string]$RedshiftNodeType       = "dc2.large",
    [int]$RedshiftNumberOfNodes     = 1,
    [string]$RedshiftMasterUsername = "dwadmin",
    [string]$RedshiftMasterPassword = "",

    # ── DocumentDB ───────────────────────────────────────────
    [string]$DocDBInstanceClass     = "db.t3.medium",
    [string]$DocDBMasterUsername    = "docdbadmin",
    [string]$DocDBMasterPassword    = "",

    # ── Timestream ───────────────────────────────────────────
    [string]$TimestreamTableName    = "metrics",
    [int]$TimestreamMemoryHours     = 24,
    [int]$TimestreamMagneticDays    = 365,

    # ── ALB ──────────────────────────────────────────────────
    [string]$ALBPublicSubnet1  = "",
    [string]$ALBPublicSubnet2  = "",
    [string]$ALBCertificateArn = "",
    [string]$ALBHealthCheckPath = "/health",

    # ── CloudFront ────────────────────────────────────────────
    [string]$CFOriginDomain    = "",
    [string]$CFPriceClass      = "PriceClass_100",

    # ── Route 53 ─────────────────────────────────────────────
    [string]$HostedZoneId      = "",
    [string]$DomainName        = "",
    [string]$ALBDnsName        = "",
    [string]$ALBHostedZoneId   = "",

    # ── IAM / KMS ─────────────────────────────────────────────
    [string]$KMSKeyPurpose     = "general",
    [string]$KMSServicePrincipal = "",

    # ── WAF ──────────────────────────────────────────────────
    [string]$WAFScope          = "REGIONAL",
    [int]$WAFRateLimit         = 100,

    # ── GuardDuty ─────────────────────────────────────────────
    [string]$GDFindingFrequency = "ONE_HOUR",

    # ── CloudTrail ────────────────────────────────────────────
    [string]$CloudTrailBucket  = "",
    [string]$CloudTrailKMSKey  = "",

    # ── Cognito ──────────────────────────────────────────────
    [string]$CognitoPoolName   = "app-users",
    [string]$CognitoCallbackURL = "https://localhost/callback",

    # ── Secrets Manager ───────────────────────────────────────
    [string]$SecretName        = "app-secret",
    [string]$SecretKMSKey      = "",

    # ── Kinesis ──────────────────────────────────────────────
    [int]$KinesisShardCount    = 1,
    [int]$KinesisRetentionHours = 24,

    # ── Athena ───────────────────────────────────────────────
    [string]$DataLakeBucket    = "",
    [string]$AthenaKMSKey      = "",
    [long]$AthenaMaxBytes      = 10737418240,

    # ── Glue ─────────────────────────────────────────────────
    [string]$GlueDatabaseName  = "analytics_db",
    [string]$GlueDataPrefix    = "data/",
    [string]$GlueSchedule      = "cron(0 2 * * ? *)",

    # ── EMR ──────────────────────────────────────────────────
    [string]$EMRRelease        = "emr-7.0.0",
    [string]$EMRMasterType     = "m5.xlarge",
    [string]$EMRCoreType       = "m5.xlarge",
    [int]$EMRCoreCount         = 2,
    [string]$EMRKMSKey         = "",

    # ── OpenSearch ────────────────────────────────────────────
    [string]$OSInstanceType    = "t3.small.search",
    [int]$OSInstanceCount      = 1,
    [int]$OSVolumeSize         = 10,
    [string]$OSKMSKey          = "",

    # ── SQS ──────────────────────────────────────────────────
    [int]$SQSRetentionSeconds  = 86400,
    [int]$SQSVisibilityTimeout = 30,
    [int]$SQSMaxReceiveCount   = 3,

    # ── SNS ──────────────────────────────────────────────────
    [string]$SNSAlertEmail     = "",
    [string]$SNSSQSSubscription = "",

    # ── SES ──────────────────────────────────────────────────
    [string]$SESFromDomain     = "",

    # ── EventBridge ──────────────────────────────────────────
    [string]$EventSource       = "myapp.orders",
    [string]$EventTargetSQS    = "",
    [string]$EventTargetLambda = "",

    # ── Step Functions ────────────────────────────────────────
    [string]$SFNType           = "STANDARD",
    [string]$SFNSQSUrl         = "",
    [string]$SFNSNSArn         = "",

    # ── IoT Core ─────────────────────────────────────────────
    [string]$IoTThingName      = "my-device",
    [string]$IoTSQSArn         = "",

    # ── CloudWatch ───────────────────────────────────────────
    [string]$CWAlertEmail      = "",
    [int]$CWLogRetentionDays   = 14,
    [int]$CWErrorThreshold     = 10,
    [int]$CWCostThreshold      = 100,

    # ── ECR ──────────────────────────────────────────────────
    [string]$ECRRepoName       = "app",
    [string]$ECRScanOnPush     = "true",
    [int]$ECRKeepImageCount    = 10,

    # ── CodePipeline ─────────────────────────────────────────
    [string]$ArtifactBucket    = "",
    [string]$CodeStarConnArn   = "",
    [string]$GitHubOwner       = "",
    [string]$GitHubRepo        = "",
    [string]$GitHubBranch      = "main",
    [string]$ECRRepoUri        = "",
    [string]$PipelineSNS       = "",

    # ── Systems Manager ───────────────────────────────────────
    [string]$SSMAppConfig      = '{"env":"dev"}',

    # ── SageMaker ────────────────────────────────────────────
    [string]$SMInstanceType    = "ml.t3.medium",
    [int]$SMVolumeGB           = 20,
    [string]$SMDataBucket      = "",
    [string]$SMKMSKey          = "",

    # ── Bedrock ──────────────────────────────────────────────
    [string]$BedrockModelId    = "anthropic.claude-3-5-sonnet-20241022-v2:0",

    # ── Rekognition ───────────────────────────────────────────
    [string]$RekImagesBucket   = "",
    [string]$RekImagesPrefix   = "images/",
    [string]$RekCollectionId   = "faces",

    # ── Transcribe ───────────────────────────────────────────
    [string]$TranscribeAudioBucket  = "",
    [string]$TranscribeOutputBucket = "",
    [string]$TranscribeKMSKey       = "",

    # ── Polly ────────────────────────────────────────────────
    [string]$PollyOutputBucket = "",
    [string]$PollyDefaultVoice = "Joanna",

    # ── Lex ──────────────────────────────────────────────────
    [string]$LexBotName        = "AppAssistant",
    [string]$LexBotLocale      = "en_US",

    # ── Comprehend ───────────────────────────────────────────
    [string]$ComprehendInputBucket  = "",
    [string]$ComprehendOutputBucket = "",
    [string]$ComprehendKMSKey       = "",

    # ── Translate ────────────────────────────────────────────
    [string]$TranslateSourceLang  = "en",
    [string]$TranslateTargetLang  = "es",
    [string]$TranslateTermBucket  = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ─────────────────────────────────────────────────────────────────────────────
#  SERVICE CATALOGUE
# ─────────────────────────────────────────────────────────────────────────────
$ServiceCatalogue = [ordered]@{
    # ── COMPUTE ──────────────────────────────────────────────────────────────
    "ec2"               = @{ File="ec2.yaml";               Category="Compute";   Description="Virtual server in the cloud" }
    "lambda"            = @{ File="lambda.yaml";            Category="Compute";   Description="Run code without servers" }
    "ecs-fargate"       = @{ File="ecs-fargate.yaml";       Category="Compute";   Description="Containers without managing servers" }
    "auto-scaling"      = @{ File="auto-scaling.yaml";      Category="Compute";   Description="Automatic EC2 capacity adjustment" }
    "elastic-beanstalk" = @{ File="elastic-beanstalk.yaml"; Category="Compute";   Description="Managed web app deployment platform" }
    # ── STORAGE ──────────────────────────────────────────────────────────────
    "s3"                = @{ File="s3.yaml";                Category="Storage";   Description="Scalable object storage with Glacier lifecycle" }
    "efs"               = @{ File="efs.yaml";               Category="Storage";   Description="Shared file system for Linux workloads" }
    # ── DATABASE ─────────────────────────────────────────────────────────────
    "rds"               = @{ File="rds.yaml";               Category="Database";  Description="Managed relational DB (MySQL/PostgreSQL/MariaDB)" }
    "dynamodb"          = @{ File="dynamodb.yaml";          Category="Database";  Description="Managed NoSQL key-value database" }
    "elasticache-redis" = @{ File="elasticache-redis.yaml"; Category="Database";  Description="In-memory Redis cache" }
    "redshift"          = @{ File="redshift.yaml";          Category="Database";  Description="Cloud data warehouse" }
    "documentdb"        = @{ File="documentdb.yaml";        Category="Database";  Description="Managed MongoDB-compatible database" }
    "timestream"        = @{ File="timestream.yaml";        Category="Database";  Description="Serverless time-series database" }
    # ── NETWORKING ───────────────────────────────────────────────────────────
    "vpc"               = @{ File="vpc.yaml";               Category="Networking"; Description="Virtual network with public and private subnets" }
    "alb"               = @{ File="alb.yaml";               Category="Networking"; Description="Application Load Balancer (Layer 7)" }
    "cloudfront"        = @{ File="cloudfront.yaml";        Category="Networking"; Description="Global CDN with edge caching" }
    "route53"           = @{ File="route53.yaml";           Category="Networking"; Description="DNS routing with health checks" }
    # ── SECURITY ─────────────────────────────────────────────────────────────
    "iam"               = @{ File="iam.yaml";               Category="Security";  Description="Identity roles with MFA and permission boundaries" }
    "kms"               = @{ File="kms.yaml";               Category="Security";  Description="Managed encryption key with auto-rotation" }
    "waf"               = @{ File="waf.yaml";               Category="Security";  Description="WAF v2 with OWASP rules and rate limiting" }
    "guardduty"         = @{ File="guardduty.yaml";         Category="Security";  Description="Intelligent threat detection" }
    "cloudtrail"        = @{ File="cloudtrail.yaml";        Category="Security";  Description="API audit log across all AWS services" }
    "cognito"           = @{ File="cognito.yaml";           Category="Security";  Description="User authentication and authorization" }
    "secrets-manager"   = @{ File="secrets-manager.yaml";  Category="Security";  Description="Secure secrets storage and rotation" }
    # ── ANALYTICS ────────────────────────────────────────────────────────────
    "kinesis"           = @{ File="kinesis.yaml";           Category="Analytics"; Description="Real-time data streaming" }
    "athena"            = @{ File="athena.yaml";            Category="Analytics"; Description="Serverless SQL queries on S3" }
    "glue"              = @{ File="glue.yaml";              Category="Analytics"; Description="Serverless ETL and data catalog" }
    "emr"               = @{ File="emr.yaml";               Category="Analytics"; Description="Big data processing with Spark/Hadoop" }
    "opensearch"        = @{ File="opensearch.yaml";        Category="Analytics"; Description="Managed search and analytics engine" }
    # ── MESSAGING ────────────────────────────────────────────────────────────
    "sqs"               = @{ File="sqs.yaml";               Category="Messaging"; Description="Message queue with Dead Letter Queue" }
    "sns"               = @{ File="sns.yaml";               Category="Messaging"; Description="Pub/sub notification service" }
    "ses"               = @{ File="ses.yaml";               Category="Messaging"; Description="Transactional email sending" }
    "eventbridge"       = @{ File="eventbridge.yaml";       Category="Messaging"; Description="Serverless event routing bus" }
    "step-functions"    = @{ File="step-functions.yaml";    Category="Messaging"; Description="Serverless workflow orchestration" }
    "iot-core"          = @{ File="iot-core.yaml";          Category="Messaging"; Description="Connect and manage IoT devices" }
    # ── DEVOPS ───────────────────────────────────────────────────────────────
    "cloudwatch"        = @{ File="cloudwatch.yaml";        Category="DevOps";   Description="Monitoring, alarms, dashboards, and budgets" }
    "ecr"               = @{ File="ecr.yaml";               Category="DevOps";   Description="Container image registry" }
    "codepipeline"      = @{ File="codepipeline.yaml";      Category="DevOps";   Description="CI/CD pipeline with CodeBuild" }
    "systems-manager"   = @{ File="systems-manager.yaml";   Category="DevOps";   Description="Parameter Store and Session Manager" }
    # ── AI / ML ──────────────────────────────────────────────────────────────
    "sagemaker"         = @{ File="sagemaker.yaml";         Category="AI/ML";    Description="Build, train, and deploy ML models" }
    "bedrock"           = @{ File="bedrock.yaml";           Category="AI/ML";    Description="Foundation model API (Claude, Titan, Llama)" }
    "rekognition"       = @{ File="rekognition.yaml";       Category="AI/ML";    Description="Image and video analysis" }
    "transcribe"        = @{ File="transcribe.yaml";        Category="AI/ML";    Description="Automatic speech-to-text" }
    "polly"             = @{ File="polly.yaml";             Category="AI/ML";    Description="Text-to-speech synthesis" }
    "lex"               = @{ File="lex.yaml";               Category="AI/ML";    Description="Conversational chatbot builder" }
    "comprehend"        = @{ File="comprehend.yaml";        Category="AI/ML";    Description="NLP — sentiment, entities, key phrases" }
    "translate"         = @{ File="translate.yaml";         Category="AI/ML";    Description="Neural machine translation (75+ languages)" }
}

# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────
function Write-Header([string]$Text) {
    $w = 72
    Write-Host ("`n" + ("═" * $w)) -ForegroundColor Cyan
    Write-Host ("  $Text") -ForegroundColor Cyan
    Write-Host (("═" * $w)) -ForegroundColor Cyan
}

function Write-Step([string]$Text)    { Write-Host "  ► $Text" -ForegroundColor Yellow }
function Write-Success([string]$Text) { Write-Host "  ✓ $Text" -ForegroundColor Green }
function Write-Err([string]$Text)     { Write-Host "  ✗ $Text" -ForegroundColor Red }
function Write-Info([string]$Text)    { Write-Host "  · $Text" -ForegroundColor DarkGray }

function Get-SecureInput([string]$Prompt) {
    $s = Read-Host -Prompt $Prompt -AsSecureString
    $b = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
    return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($b)
}

function Invoke-Deploy {
    param(
        [string]$StackName,
        [string]$TemplateFile,
        [hashtable]$Params,
        [string]$Region
    )
    if (-not (Test-Path $TemplateFile)) {
        Write-Err "Template not found: $TemplateFile"
        return $false
    }

    # Filter out empty string params to avoid CloudFormation errors
    $filtered = @{}
    foreach ($kv in $Params.GetEnumerator()) {
        if (-not [string]::IsNullOrWhiteSpace($kv.Value)) {
            $filtered[$kv.Key] = $kv.Value
        }
    }

    $paramOverrides = ($filtered.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" })

    Write-Step "Stack:    $StackName"
    Write-Step "Template: $(Split-Path $TemplateFile -Leaf)"
    Write-Step "Region:   $Region"

    $cliArgs = @(
        "cloudformation", "deploy",
        "--stack-name", $StackName,
        "--template-file", $TemplateFile,
        "--region", $Region,
        "--capabilities", "CAPABILITY_NAMED_IAM", "CAPABILITY_AUTO_EXPAND",
        "--no-fail-on-empty-changeset"
    )
    if ($paramOverrides.Count -gt 0) {
        $cliArgs += "--parameter-overrides"
        $cliArgs += $paramOverrides
    }

    aws @cliArgs

    if ($LASTEXITCODE -eq 0) {
        Write-Success "Deployed successfully: $StackName"
        return $true
    } else {
        Write-Err "Deployment FAILED: $StackName"
        Write-Host ""
        Write-Host "  ▶ To diagnose, run:" -ForegroundColor Yellow
        Write-Host "    aws cloudformation describe-stack-events --stack-name $StackName --region $Region --output table" -ForegroundColor Cyan
        return $false
    }
}

# ─────────────────────────────────────────────────────────────────────────────
#  LIST SERVICES
# ─────────────────────────────────────────────────────────────────────────────
if ($ListServices) {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║            AWS Individual Service Templates — 47 services           ║" -ForegroundColor Cyan
    Write-Host "  ╚══════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan

    $currentCat = ""
    foreach ($svc in $ServiceCatalogue.GetEnumerator()) {
        $cat = $svc.Value.Category
        if ($cat -ne $currentCat) {
            Write-Host ""
            Write-Host "  ── $cat ──────────────────────────────────────" -ForegroundColor DarkYellow
            $currentCat = $cat
        }
        Write-Host ("  {0,-20} {1}" -f $svc.Key, $svc.Value.Description) -ForegroundColor White
    }
    Write-Host ""
    Write-Host "  Usage:  .\Deploy-Individual.ps1 -Service <name> -ProjectName myapp -EnvironmentName dev" -ForegroundColor DarkGray
    Write-Host ""
    exit 0
}

# ─────────────────────────────────────────────────────────────────────────────
#  VALIDATE SERVICE
# ─────────────────────────────────────────────────────────────────────────────
if ([string]::IsNullOrWhiteSpace($Service)) {
    Write-Err "No service specified. Use -Service <name> or -ListServices"
    Write-Host "  Example: .\Deploy-Individual.ps1 -ListServices" -ForegroundColor Yellow
    exit 1
}

$svcKey = $Service.ToLower()
if (-not $ServiceCatalogue.Contains($svcKey)) {
    Write-Err "Unknown service: '$Service'"
    Write-Host "  Run -ListServices to see all available services." -ForegroundColor Yellow
    exit 1
}

$svcDef   = $ServiceCatalogue[$svcKey]
$template = Join-Path $TemplateDir $svcDef.File
$stack    = "$ProjectName-$EnvironmentName-$svcKey"

# Verify AWS CLI
try { aws --version 2>&1 | Out-Null } catch {
    Write-Err "AWS CLI not found. Install from https://aws.amazon.com/cli/"
    exit 1
}
try {
    $acct = aws sts get-caller-identity --query Account --output text 2>&1
    if ($LASTEXITCODE -ne 0) { throw }
} catch {
    Write-Err "Cannot authenticate. Run: aws configure"
    exit 1
}

Write-Header "Deploying: $($svcDef.Category) › $svcKey"
Write-Info "Description : $($svcDef.Description)"
Write-Info "Project     : $ProjectName"
Write-Info "Environment : $EnvironmentName"
Write-Info "Account     : $acct"
Write-Info "Region      : $Region"

# ─────────────────────────────────────────────────────────────────────────────
#  PARAMETER MAP PER SERVICE
# ─────────────────────────────────────────────────────────────────────────────
$params = @{ ProjectName = $ProjectName; EnvironmentName = $EnvironmentName }

switch ($svcKey) {

    # ════════════════════════════ COMPUTE ════════════════════════════════════

    "ec2" {
        if ([string]::IsNullOrEmpty($VpcId))    { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetId)) { Write-Err "Required: -SubnetId (private subnet)"; exit 1 }
        $params += @{ InstanceType=$EC2InstanceType; EC2VolumeSize=$EC2VolumeSize
                      VpcId=$VpcId; SubnetId=$SubnetId; KeyPairName=$EC2KeyPairName }
    }

    "lambda" {
        $params += @{ Runtime=$LambdaRuntime; MemorySize=$LambdaMemorySize
                      Timeout=$LambdaTimeout; ReservedConcurrency=$LambdaReservedConcurrency }
    }

    "ecs-fargate" {
        if ([string]::IsNullOrEmpty($VpcId))     { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetIds)) { Write-Err "Required: -SubnetIds (comma-separated private subnets)"; exit 1 }
        $params += @{ ContainerImage=$ECSContainerImage; ContainerPort=$ECSContainerPort
                      TaskCPU=$ECSTaskCPU; TaskMemory=$ECSTaskMemory; DesiredCount=$ECSDesiredCount
                      VpcId=$VpcId; SubnetIds=$SubnetIds }
    }

    "auto-scaling" {
        if ([string]::IsNullOrEmpty($VpcId))     { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetIds)) { Write-Err "Required: -SubnetIds"; exit 1 }
        $params += @{ InstanceType=$EC2InstanceType; VolumeSize=$EC2VolumeSize
                      VpcId=$VpcId; SubnetIds=$SubnetIds
                      MinSize=$ASGMinSize; MaxSize=$ASGMaxSize
                      DesiredCapacity=$ASGDesiredCapacity; CPUTargetUtilization=$ASGCPUTarget }
    }

    "elastic-beanstalk" {
        $params += @{ Platform=$BeanstalkPlatform; InstanceType=$BeanstalkInstanceType }
    }

    # ════════════════════════════ STORAGE ════════════════════════════════════

    "s3" {
        $params += @{ BucketName=$S3BucketName; GlacierTransitionDays=$S3GlacierDays
                      ExpirationDays=$S3ExpirationDays }
    }

    "efs" {
        if ([string]::IsNullOrEmpty($VpcId))    { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetId)) { Write-Err "Required: -SubnetId"; exit 1 }
        $params += @{ VpcId=$VpcId; SubnetId=$SubnetId
                      PerformanceMode=$EFSPerformanceMode; ThroughputMode=$EFSThroughputMode }
    }

    # ════════════════════════════ DATABASE ═══════════════════════════════════

    "rds" {
        if ([string]::IsNullOrEmpty($VpcId))     { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetIds)) { Write-Err "Required: -SubnetIds (2 subnets in different AZs)"; exit 1 }
        if ([string]::IsNullOrEmpty($RDSMasterPassword)) { $RDSMasterPassword = Get-SecureInput "RDS Master Password (min 12 chars)" }
        $params += @{ Engine=$RDSEngine; EngineVersion=$RDSEngineVersion; InstanceClass=$RDSInstanceClass
                      DBName=$RDSDBName; MasterUsername=$RDSMasterUsername; MasterPassword=$RDSMasterPassword
                      VpcId=$VpcId; SubnetIds=$SubnetIds }
    }

    "dynamodb" {
        $params += @{ TableName=$DynamoTableName; HashKey=$DynamoHashKey
                      RangeKey=$DynamoRangeKey; BillingMode=$DynamoBillingMode }
    }

    "elasticache-redis" {
        if ([string]::IsNullOrEmpty($VpcId))     { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetIds)) { Write-Err "Required: -SubnetIds (2 subnets in different AZs)"; exit 1 }
        $params += @{ NodeType=$RedisNodeType; NumReplicas=$RedisNumReplicas
                      VpcId=$VpcId; SubnetIds=$SubnetIds }
    }

    "redshift" {
        if ([string]::IsNullOrEmpty($VpcId))     { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetIds)) { Write-Err "Required: -SubnetIds"; exit 1 }
        if ([string]::IsNullOrEmpty($RedshiftMasterPassword)) { $RedshiftMasterPassword = Get-SecureInput "Redshift Master Password (min 12 chars)" }
        $params += @{ NodeType=$RedshiftNodeType; NumberOfNodes=$RedshiftNumberOfNodes
                      MasterUsername=$RedshiftMasterUsername; MasterPassword=$RedshiftMasterPassword
                      VpcId=$VpcId; SubnetIds=$SubnetIds }
    }

    "documentdb" {
        if ([string]::IsNullOrEmpty($VpcId))     { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetIds)) { Write-Err "Required: -SubnetIds"; exit 1 }
        if ([string]::IsNullOrEmpty($DocDBMasterPassword)) { $DocDBMasterPassword = Get-SecureInput "DocumentDB Master Password (min 12 chars)" }
        $params += @{ InstanceClass=$DocDBInstanceClass
                      MasterUsername=$DocDBMasterUsername; MasterPassword=$DocDBMasterPassword
                      VpcId=$VpcId; SubnetIds=$SubnetIds }
    }

    "timestream" {
        $params += @{ TableName=$TimestreamTableName
                      MemoryRetentionHours=$TimestreamMemoryHours
                      MagneticRetentionDays=$TimestreamMagneticDays }
    }

    # ════════════════════════════ NETWORKING ═════════════════════════════════

    "vpc" {
        $params += @{ VpcCIDR=$VpcCIDR; PublicSubnet1CIDR=$PublicSubnet1CIDR
                      PublicSubnet2CIDR=$PublicSubnet2CIDR; PrivateSubnet1CIDR=$PrivateSubnet1CIDR
                      PrivateSubnet2CIDR=$PrivateSubnet2CIDR }
    }

    "alb" {
        if ([string]::IsNullOrEmpty($VpcId))          { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($ALBPublicSubnet1)) { Write-Err "Required: -ALBPublicSubnet1"; exit 1 }
        if ([string]::IsNullOrEmpty($ALBPublicSubnet2)) { Write-Err "Required: -ALBPublicSubnet2"; exit 1 }
        $params += @{ VpcId=$VpcId; PublicSubnet1=$ALBPublicSubnet1; PublicSubnet2=$ALBPublicSubnet2
                      CertificateArn=$ALBCertificateArn; HealthCheckPath=$ALBHealthCheckPath }
    }

    "cloudfront" {
        if ([string]::IsNullOrEmpty($CFOriginDomain)) { Write-Err "Required: -CFOriginDomain"; exit 1 }
        $params += @{ OriginDomain=$CFOriginDomain; PriceClass=$CFPriceClass }
    }

    "route53" {
        if ([string]::IsNullOrEmpty($HostedZoneId))  { Write-Err "Required: -HostedZoneId"; exit 1 }
        if ([string]::IsNullOrEmpty($DomainName))    { Write-Err "Required: -DomainName"; exit 1 }
        if ([string]::IsNullOrEmpty($ALBDnsName))    { Write-Err "Required: -ALBDnsName"; exit 1 }
        if ([string]::IsNullOrEmpty($ALBHostedZoneId)) { Write-Err "Required: -ALBHostedZoneId"; exit 1 }
        $params += @{ HostedZoneId=$HostedZoneId; DomainName=$DomainName
                      ALBDnsName=$ALBDnsName; ALBHostedZoneId=$ALBHostedZoneId }
    }

    # ════════════════════════════ SECURITY ═══════════════════════════════════

    "iam"             { $params += @{} }
    "kms"             { $params += @{ KeyPurpose=$KMSKeyPurpose; AllowedServicePrincipal=$KMSServicePrincipal } }
    "waf"             { $params += @{ Scope=$WAFScope; RateLimitPerIP=$WAFRateLimit } }
    "guardduty"       { $params += @{ FindingFrequency=$GDFindingFrequency } }

    "cloudtrail" {
        if ([string]::IsNullOrEmpty($CloudTrailBucket)) { Write-Err "Required: -CloudTrailBucket"; exit 1 }
        $params += @{ S3BucketName=$CloudTrailBucket; KMSKeyArn=$CloudTrailKMSKey }
    }

    "cognito" {
        $params += @{ UserPoolName=$CognitoPoolName; CallbackURL=$CognitoCallbackURL }
    }

    "secrets-manager" {
        $params += @{ SecretName=$SecretName; KMSKeyArn=$SecretKMSKey }
    }

    # ════════════════════════════ ANALYTICS ══════════════════════════════════

    "kinesis" {
        $params += @{ ShardCount=$KinesisShardCount; RetentionHours=$KinesisRetentionHours }
    }

    "athena" {
        if ([string]::IsNullOrEmpty($DataLakeBucket)) { Write-Err "Required: -DataLakeBucket"; exit 1 }
        $params += @{ DataLakeBucketName=$DataLakeBucket; KMSKeyArn=$AthenaKMSKey
                      MaxBytesScannedPerQuery=$AthenaMaxBytes }
    }

    "glue" {
        if ([string]::IsNullOrEmpty($DataLakeBucket)) { Write-Err "Required: -DataLakeBucket"; exit 1 }
        $params += @{ DataLakeBucketName=$DataLakeBucket; DataLakePrefix=$GlueDataPrefix
                      CrawlerSchedule=$GlueSchedule; GlueDatabaseName=$GlueDatabaseName }
    }

    "emr" {
        if ([string]::IsNullOrEmpty($VpcId))          { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetId))       { Write-Err "Required: -SubnetId"; exit 1 }
        if ([string]::IsNullOrEmpty($DataLakeBucket)) { Write-Err "Required: -DataLakeBucket"; exit 1 }
        $params += @{ ReleaseLabel=$EMRRelease; MasterInstanceType=$EMRMasterType
                      CoreInstanceType=$EMRCoreType; CoreInstanceCount=$EMRCoreCount
                      DataLakeBucketName=$DataLakeBucket; SubnetId=$SubnetId
                      VpcId=$VpcId; KMSKeyArn=$EMRKMSKey }
    }

    "opensearch" {
        if ([string]::IsNullOrEmpty($VpcId))    { Write-Err "Required: -VpcId"; exit 1 }
        if ([string]::IsNullOrEmpty($SubnetId)) { Write-Err "Required: -SubnetId"; exit 1 }
        $params += @{ InstanceType=$OSInstanceType; InstanceCount=$OSInstanceCount
                      VolumeSize=$OSVolumeSize; VpcId=$VpcId; SubnetId=$SubnetId; KMSKeyArn=$OSKMSKey }
    }

    # ════════════════════════════ MESSAGING ══════════════════════════════════

    "sqs" {
        $params += @{ MessageRetentionSeconds=$SQSRetentionSeconds
                      VisibilityTimeout=$SQSVisibilityTimeout; MaxReceiveCount=$SQSMaxReceiveCount }
    }

    "sns" {
        $params += @{ AlertEmail=$SNSAlertEmail; SQSSubscriptionArn=$SNSSQSSubscription }
    }

    "ses" {
        if ([string]::IsNullOrEmpty($SESFromDomain)) { Write-Err "Required: -SESFromDomain (e.g. example.com)"; exit 1 }
        $params += @{ FromDomain=$SESFromDomain }
    }

    "eventbridge" {
        $params += @{ EventSource=$EventSource; TargetSQSArn=$EventTargetSQS
                      TargetLambdaArn=$EventTargetLambda }
    }

    "step-functions" {
        $params += @{ StateMachineType=$SFNType; SQSQueueUrl=$SFNSQSUrl; SNSTopicArn=$SFNSNSArn }
    }

    "iot-core" {
        $params += @{ ThingName=$IoTThingName; TargetSQSArn=$IoTSQSArn }
    }

    # ════════════════════════════ DEVOPS ═════════════════════════════════════

    "cloudwatch" {
        $params += @{ AlertEmail=$CWAlertEmail; LogRetentionDays=$CWLogRetentionDays
                      ErrorAlarmThreshold=$CWErrorThreshold; MonthlyCostThresholdUSD=$CWCostThreshold }
    }

    "ecr" {
        $params += @{ RepositoryName=$ECRRepoName; ScanOnPush=$ECRScanOnPush
                      KeepTaggedImageCount=$ECRKeepImageCount }
    }

    "codepipeline" {
        if ([string]::IsNullOrEmpty($ArtifactBucket))  { Write-Err "Required: -ArtifactBucket"; exit 1 }
        if ([string]::IsNullOrEmpty($CodeStarConnArn)) { Write-Err "Required: -CodeStarConnArn"; exit 1 }
        if ([string]::IsNullOrEmpty($GitHubOwner))     { Write-Err "Required: -GitHubOwner"; exit 1 }
        if ([string]::IsNullOrEmpty($GitHubRepo))      { Write-Err "Required: -GitHubRepo"; exit 1 }
        $params += @{ ArtifactBucketName=$ArtifactBucket; CodeStarConnectionArn=$CodeStarConnArn
                      GitHubOwner=$GitHubOwner; GitHubRepo=$GitHubRepo; GitHubBranch=$GitHubBranch
                      ECRRepositoryUri=$ECRRepoUri; NotificationTopicArn=$PipelineSNS }
    }

    "systems-manager" {
        $params += @{ AppConfigValue=$SSMAppConfig }
    }

    # ════════════════════════════ AI / ML ════════════════════════════════════

    "sagemaker" {
        if ([string]::IsNullOrEmpty($SMDataBucket)) { Write-Err "Required: -SMDataBucket"; exit 1 }
        $params += @{ NotebookInstanceType=$SMInstanceType; VolumeSizeGB=$SMVolumeGB
                      ModelDataBucketName=$SMDataBucket; KMSKeyArn=$SMKMSKey }
    }

    "bedrock" {
        $params += @{ ModelId=$BedrockModelId }
    }

    "rekognition" {
        if ([string]::IsNullOrEmpty($RekImagesBucket)) { Write-Err "Required: -RekImagesBucket"; exit 1 }
        $params += @{ ImagesBucketName=$RekImagesBucket; ImagesPrefix=$RekImagesPrefix
                      CollectionId=$RekCollectionId }
    }

    "transcribe" {
        if ([string]::IsNullOrEmpty($TranscribeAudioBucket)) { Write-Err "Required: -TranscribeAudioBucket"; exit 1 }
        $params += @{ AudioBucketName=$TranscribeAudioBucket; KMSKeyArn=$TranscribeKMSKey }
    }

    "polly" {
        if ([string]::IsNullOrEmpty($PollyOutputBucket)) { Write-Err "Required: -PollyOutputBucket"; exit 1 }
        $params += @{ OutputBucketName=$PollyOutputBucket; DefaultVoice=$PollyDefaultVoice }
    }

    "lex" {
        $params += @{ BotName=$LexBotName; BotLocale=$LexBotLocale }
    }

    "comprehend" {
        if ([string]::IsNullOrEmpty($ComprehendInputBucket))  { Write-Err "Required: -ComprehendInputBucket"; exit 1 }
        if ([string]::IsNullOrEmpty($ComprehendOutputBucket)) { Write-Err "Required: -ComprehendOutputBucket"; exit 1 }
        $params += @{ InputBucketName=$ComprehendInputBucket; OutputBucketName=$ComprehendOutputBucket
                      KMSKeyArn=$ComprehendKMSKey }
    }

    "translate" {
        $params += @{ SourceLanguage=$TranslateSourceLang; TargetLanguage=$TranslateTargetLang
                      TerminologyBucketName=$TranslateTermBucket }
    }
}

# ─────────────────────────────────────────────────────────────────────────────
#  DEPLOY
# ─────────────────────────────────────────────────────────────────────────────
$ok = Invoke-Deploy -StackName $stack -TemplateFile $template -Params $params -Region $Region

if ($ok) {
    Write-Header "STACK OUTPUTS"
    aws cloudformation describe-stacks `
        --stack-name $stack `
        --region $Region `
        --query "Stacks[0].Outputs" `
        --output table 2>$null

    Write-Host ""
    Write-Host "  ▶ View in Console:" -ForegroundColor DarkGray
    Write-Host "    https://$Region.console.aws.amazon.com/cloudformation/home?region=$Region#/stacks" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  ▶ Delete this stack:" -ForegroundColor DarkGray
    Write-Host "    aws cloudformation delete-stack --stack-name $stack --region $Region" -ForegroundColor Cyan
    Write-Host ""
    Write-Success "Done!"
    exit 0
} else {
    exit 1
}
