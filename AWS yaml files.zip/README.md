# AWS Individual Service CloudFormation Templates

47 standalone templates — one file per AWS service. Each template is
fully parameterised, least-privilege IAM, KMS-encrypted, and ready to deploy.

---

## Quick Start

```powershell
# 1. Configure AWS credentials
aws configure

# 2. List all available services
.\Deploy-Individual.ps1 -ListServices

# 3. Deploy any service
.\Deploy-Individual.ps1 -Service dynamodb -ProjectName myapp -EnvironmentName dev -Region ap-south-1
```

---

## File Layout

```
cfn-individual/
│
├── Deploy-Individual.ps1        ← Single deploy script for all 47 services
├── README.md                    ← This file
│
├── ── COMPUTE ──────────────────────────────────────────────
├── ec2.yaml                     EC2 instance (IMDSv2, SSM-only, encrypted gp3)
├── lambda.yaml                  Lambda function (scoped logs, reserved concurrency)
├── ecs-fargate.yaml             ECS Fargate service (no public IP, read-only FS)
├── auto-scaling.yaml            Auto Scaling Group (launch template, CPU target)
├── elastic-beanstalk.yaml       Elastic Beanstalk (separate service/instance roles)
│
├── ── STORAGE ──────────────────────────────────────────────
├── s3.yaml                      S3 bucket (block public, KMS, HTTPS-only policy)
├── efs.yaml                     EFS file system (NFS locked to VPC, access point)
│
├── ── DATABASE ─────────────────────────────────────────────
├── rds.yaml                     RDS instance (IAM auth, no public, Multi-AZ prod)
├── dynamodb.yaml                DynamoDB table (KMS, PITR, read/write policies)
├── elasticache-redis.yaml       ElastiCache Redis (KMS, TLS, auto-failover prod)
├── redshift.yaml                Redshift cluster (KMS, no public, snapshot prod)
├── documentdb.yaml              DocumentDB cluster (KMS, deletion protection prod)
├── timestream.yaml              Timestream DB (KMS, hot+cold retention, write/query)
│
├── ── NETWORKING ───────────────────────────────────────────
├── vpc.yaml                     VPC (public+private subnets, NAT GW, flow logs)
├── alb.yaml                     ALB (HTTP→HTTPS redirect, TLS 1.3, invalid header drop)
├── cloudfront.yaml              CloudFront (HTTPS-only origin, HTTP/3, viewer redirect)
├── route53.yaml                 Route 53 (alias record, health check, evaluate target)
│
├── ── SECURITY ─────────────────────────────────────────────
├── iam.yaml                     IAM roles (MFA required, permission boundary)
├── kms.yaml                     KMS key (auto-rotation, service principal policy)
├── waf.yaml                     WAF v2 (OWASP + SQLi + bad inputs + rate limit)
├── guardduty.yaml               GuardDuty (S3+EKS+malware, HIGH findings → SNS)
├── cloudtrail.yaml              CloudTrail (log validation, KMS, S3 data events)
├── cognito.yaml                 Cognito (MFA prod, SRP only, advanced security)
├── secrets-manager.yaml         Secrets Manager (KMS, deny-delete policy, read role)
│
├── ── ANALYTICS ────────────────────────────────────────────
├── kinesis.yaml                 Kinesis Streams (KMS, producer/consumer policies)
├── athena.yaml                  Athena (workgroup, encrypted results, byte limit)
├── glue.yaml                    Glue (crawler + ETL role, catalog database)
├── emr.yaml                     EMR Spark cluster (encryption at rest + in transit)
├── opensearch.yaml              OpenSearch (VPC-only, KMS, node-to-node TLS)
│
├── ── MESSAGING ────────────────────────────────────────────
├── sqs.yaml                     SQS queue (KMS, DLQ, HTTPS-only, send/consume policies)
├── sns.yaml                     SNS topic (KMS, HTTPS-only, publish-only policy)
├── ses.yaml                     SES (DKIM, custom MAIL FROM, send policy)
├── eventbridge.yaml             EventBridge (custom bus, scoped rule, PutEvents policy)
├── step-functions.yaml          Step Functions (CloudWatch logs, no sensitive data logged)
├── iot-core.yaml                IoT Core (device policy per ClientId, telemetry rule)
│
├── ── DEVOPS ───────────────────────────────────────────────
├── cloudwatch.yaml              CloudWatch (log group, error alarm, dashboard, budget)
├── ecr.yaml                     ECR (immutable tags, scan on push, push/pull policies)
├── codepipeline.yaml            CodePipeline + CodeBuild (source→build→approve→deploy)
├── systems-manager.yaml         SSM Parameter Store (path-scoped IAM, KMS SecureString)
│
└── ── AI / ML ──────────────────────────────────────────────
    ├── sagemaker.yaml           SageMaker (no internet, no root, KMS volume)
    ├── bedrock.yaml             Bedrock (single-model invoke policy, audit log)
    ├── rekognition.yaml         Rekognition (detect + video policies, face collection)
    ├── transcribe.yaml          Transcribe (job-prefix scoped, KMS output)
    ├── polly.yaml               Polly (synthesis + output bucket policy)
    ├── lex.yaml                 Lex v2 (Polly-only role, session TTL, invoke policy)
    ├── comprehend.yaml          Comprehend (analyse-only policy, async job role)
    └── translate.yaml           Translate (translate-only policy, batch role)
```

---

## Deploy Examples

### Recommended Deployment Order

Most services that use a VPC should deploy **vpc** first so you can
pass its subnet and VPC IDs to everything else.

```powershell
# Step 1 — Foundation
.\Deploy-Individual.ps1 -Service vpc        -ProjectName myapp -EnvironmentName dev
.\Deploy-Individual.ps1 -Service kms        -ProjectName myapp -EnvironmentName dev -KMSKeyPurpose general
.\Deploy-Individual.ps1 -Service cloudwatch -ProjectName myapp -EnvironmentName dev -CWAlertEmail ops@example.com
.\Deploy-Individual.ps1 -Service cloudtrail -ProjectName myapp -EnvironmentName dev -CloudTrailBucket my-logs-bucket

# Step 2 — Storage & Database
.\Deploy-Individual.ps1 -Service s3         -ProjectName myapp -EnvironmentName dev
.\Deploy-Individual.ps1 -Service dynamodb   -ProjectName myapp -EnvironmentName dev -DynamoTableName orders
.\Deploy-Individual.ps1 -Service rds        -ProjectName myapp -EnvironmentName dev `
    -VpcId vpc-0abc1234 -SubnetIds "subnet-aaa,subnet-bbb" -RDSEngine postgres

# Step 3 — Networking
.\Deploy-Individual.ps1 -Service alb        -ProjectName myapp -EnvironmentName dev `
    -VpcId vpc-0abc1234 -ALBPublicSubnet1 subnet-pub1 -ALBPublicSubnet2 subnet-pub2

# Step 4 — Compute
.\Deploy-Individual.ps1 -Service ecs-fargate -ProjectName myapp -EnvironmentName dev `
    -VpcId vpc-0abc1234 -SubnetIds "subnet-priv1,subnet-priv2" -ECSContainerImage "123456789.dkr.ecr.ap-south-1.amazonaws.com/myapp:latest"

# Step 5 — Messaging
.\Deploy-Individual.ps1 -Service sqs        -ProjectName myapp -EnvironmentName dev
.\Deploy-Individual.ps1 -Service sns        -ProjectName myapp -EnvironmentName dev -SNSAlertEmail ops@example.com

# Step 6 — Security
.\Deploy-Individual.ps1 -Service waf        -ProjectName myapp -EnvironmentName dev
.\Deploy-Individual.ps1 -Service guardduty  -ProjectName myapp -EnvironmentName dev
.\Deploy-Individual.ps1 -Service cognito    -ProjectName myapp -EnvironmentName dev -CognitoCallbackURL https://myapp.example.com/callback

# Step 7 — AI/ML (no VPC needed)
.\Deploy-Individual.ps1 -Service bedrock    -ProjectName myapp -EnvironmentName dev -BedrockModelId "anthropic.claude-3-5-sonnet-20241022-v2:0"
.\Deploy-Individual.ps1 -Service rekognition -ProjectName myapp -EnvironmentName dev -RekImagesBucket myapp-dev-images
```

---

### One-liners: Common Services

```powershell
# DynamoDB — on-demand billing, PK+SK table
.\Deploy-Individual.ps1 -Service dynamodb -ProjectName myapp -EnvironmentName dev `
    -DynamoTableName users -DynamoHashKey UserId -DynamoRangeKey CreatedAt

# Lambda — Python 3.12, 512 MB
.\Deploy-Individual.ps1 -Service lambda -ProjectName myapp -EnvironmentName dev `
    -LambdaRuntime python3.12 -LambdaMemorySize 512 -LambdaTimeout 60

# SQS with Dead Letter Queue
.\Deploy-Individual.ps1 -Service sqs -ProjectName myapp -EnvironmentName dev `
    -SQSRetentionSeconds 345600 -SQSMaxReceiveCount 5

# S3 with custom name
.\Deploy-Individual.ps1 -Service s3 -ProjectName myapp -EnvironmentName dev `
    -S3BucketName my-unique-bucket-name-2026

# Bedrock — Claude Sonnet
.\Deploy-Individual.ps1 -Service bedrock -ProjectName myapp -EnvironmentName dev `
    -BedrockModelId "anthropic.claude-3-5-sonnet-20241022-v2:0"

# Cognito — production (MFA enforced)
.\Deploy-Individual.ps1 -Service cognito -ProjectName myapp -EnvironmentName prod `
    -CognitoCallbackURL "https://myapp.com/callback" -CognitoPoolName "customers"

# SageMaker notebook
.\Deploy-Individual.ps1 -Service sagemaker -ProjectName myapp -EnvironmentName dev `
    -SMDataBucket myapp-dev-ml-data -SMInstanceType ml.t3.medium

# WAF + ALB protection
.\Deploy-Individual.ps1 -Service waf -ProjectName myapp -EnvironmentName prod `
    -WAFScope REGIONAL -WAFRateLimit 100
```

---

### Delete a Stack

```powershell
aws cloudformation delete-stack --stack-name myapp-dev-dynamodb --region ap-south-1
```

### View Stack Outputs

```powershell
aws cloudformation describe-stacks --stack-name myapp-dev-dynamodb `
    --region ap-south-1 --query "Stacks[0].Outputs" --output table
```

### List All Your Stacks

```powershell
aws cloudformation list-stacks `
    --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE `
    --region ap-south-1 --output table
```

---

## Least Privilege Principles Applied

Every template follows these security rules:

| Principle | Implementation |
|-----------|---------------|
| KMS encryption | Every service has its own CMK with auto-rotation |
| No public access | Databases, ECS, SageMaker all private by default |
| Scoped IAM | Policies reference specific resource ARNs, not `*` |
| Separate roles | Read-only vs read-write vs admin — attach only what you need |
| HTTPS enforcement | S3, SQS, SNS all deny non-TLS requests |
| IMDSv2 | All EC2 / Auto Scaling templates enforce token-based metadata |
| Prod guards | Deletion protection, Multi-AZ, longer retention on `prod` env |
| No SSH | EC2 instances accessed via Session Manager only |

---

## Parameters Common to All Templates

| Parameter | Default | Description |
|-----------|---------|-------------|
| `ProjectName` | `myproject` | Used as prefix for all resource names |
| `EnvironmentName` | `dev` | Allowed: `dev`, `staging`, `prod` |

Setting `EnvironmentName=prod` automatically enables:
- Multi-AZ for RDS, ElastiCache Redis
- Deletion protection for RDS, DynamoDB, DocumentDB
- Snapshot on stack deletion for RDS, DocumentDB
- Extended log retention (90–365 days)
- CloudTrail multi-region mode
- Cognito MFA enforced

